import * as Yup from "yup";

Yup.setLocale({
mixed:{
required: "Bu alan zorunludur"
} 
})
export default Yup