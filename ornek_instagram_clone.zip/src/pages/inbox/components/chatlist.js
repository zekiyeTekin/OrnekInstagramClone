import classNames from "classnames";
import { NavLink, useParams } from "react-router-dom";

export default function ChatList() {


    const {conversationId} = useParams()
    const chats =[
        {
            id:1,
            user: {
                avatar: 'https://www.cssscript.com/wp-content/uploads/2020/12/Customizable-SVG-Avatar-Generator-In-JavaScript-Avataaars.js-150x150.png',
                name: 'Zekiye Tekin'
            },
            lastMessage: 'Selam ZekZek'
        },
        {
            id:2,
            user: {
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU',
                name: 'Mino Tekin'
            },
            unread: true,
            lastMessage: 'Heyyo zekiye yeni video attım bakkk'
        }
    ]


    return (
        <div className="h-[calc(100%-60px)] overflow-auto py-3 " > 
            <header className="flex items-center justify-between px-5 mb-1">
                <h6 className="text-base font-semibold">Messages</h6>
                <button className="text-brand text-sm font-semibold">16 requests</button>
                {/* {conversationId} */}
            </header>
            {chats.map(chat => (
                <NavLink
                className={classNames({
                    "h-[72px] flex items-center gap-x-4 hover:bg-zinc-50 px-5" : true,
                    "font-semibold" : chat?.unread,
                    "!bg-[#efefef]": +conversationId === chat.id
                })}
                key ={chat.id}
                to={`/inbox/${chat.id}`} 
                >
                    <img src={chat.user.avatar} className="w-14 h-14 rounded-full" alt="" />
                    <div>
                        <h6 className="text-sm"> {chat.user.name} </h6>
                        <p className={`text-sm ${ !chat?.unread && ' text-[#8e8e8e]' }`}>
                        {chat.lastMessage}
                        </p>
                    </div>
                </NavLink>
            ))}
        </div>
    )
}
