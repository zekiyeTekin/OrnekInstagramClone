import Header from "./components/header";
import Messages from "./components/messages";
import Reply from "./components/reply";
import { useState } from "react";


export default function Chat() {


    const user = {
        name: 'Zekiye Tekin',
        avatar: 'https://www.cssscript.com/wp-content/uploads/2020/12/Customizable-SVG-Avatar-Generator-In-JavaScript-Avataaars.js-150x150.png'
    }

    const [messages, setMessages] = useState([
        {
            from: {
                id: 'Fii5NfMKkMZ6YldXUt4EMEUIqkb2',
                name: 'Zekiye Tekin',
                username: 'zekiye_tkn',
                avatar: 'https://www.cssscript.com/wp-content/uploads/2020/12/Customizable-SVG-Avatar-Generator-In-JavaScript-Avataaars.js-150x150.png'
            },
            message: ' oylesine' 
        },
        {
            from: {
                id: 'QsMNdgOuhORq4pWeP3GfSbI0quZ2',
                name: 'Nur Tekin',
                username: 'nut_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'hayat nasıl je4  ı evfejb eröwncıwecbeıhbcwırbı'
        },
        {
            from: {
                id: 'fLIu4yRNrsPUqKyRMU14uhAkDVp1',
                name: 'Münevver Tekin',
                username: 'mino_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'test '
        },
        {
            from: {
                id: 'QsMNdgOuhORq4pWeP3GfSbI0quZ2',
                name: 'Nur Tekin',
                username: 'nut_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'loooo loo lo'
        },
        {
            from: {
                id: 'Fii5NfMKkMZ6YldXUt4EMEUIqkb2',
                name: 'Zekiye Tekin',
                username: 'zekiye_tkn',
                avatar: 'https://www.cssscript.com/wp-content/uploads/2020/12/Customizable-SVG-Avatar-Generator-In-JavaScript-Avataaars.js-150x150.png'
            },
            message: 'iste oylesine' 
        },
        {
            from: {
                id: 'QsMNdgOuhORq4pWeP3GfSbI0quZ2',
                name: 'Nur Tekin',
                username: 'nut_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'hayat nasıl je4  ı evfejb eröwncıwecbeıhbcw echwkrcnıwcfowbcfw ecfrwenjwrcfeıhbrwıne ıcfhweneıcfbehırbı'
        },
        {
            from: {
                id: 'fLIu4yRNrsPUqKyRMU14uhAkDVp1',
                name: 'Münevver Tekin',
                username: 'mino_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'test aşaması'
        },
        {
            from: {
                id: 'QsMNdgOuhORq4pWeP3GfSbI0quZ2',
                name: 'Nur Tekin',
                username: 'nut_tkn',
                avatar: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSDfSwap3iAYqS7YoldaB-ZT92aoKU9KymmtbNV3gjeJ5wI9Wed4AT8jANOQ3C6k3mI_XQ&usqp=CAU'
            },
            message: 'hayat nasıl'
        }
    ])

    return (
        <div className="flex-1">
            <Header user={user} />
            <Messages messages={messages}/>
            <Reply setMessages={setMessages} />
        </div>
    )
}