import React from "react";
import { useRef, useEffect , useState} from "react";
import Input from "../../components/Input";
import {AiFillFacebook} from "react-icons/ai";
import { useNavigate, Navigate ,useLocation , Link} from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { setUser } from "../../store/auth";
import Button from "../../components/Button";
import Separator from "../../components/Separator";
import { login } from "../../firebase";
import { Formik, Form } from "formik";
import { LoginSchema } from "../../validation";
import { Helmet } from "react-helmet";
// birüstü firebase.js de yapabilirsin


export default function Login(){
   
  const user = useSelector(state => state.auth.user)
  const navigate = useNavigate()
  const location = useLocation()
  const ref= useRef()
  // const [username, setUsername] = useState('')
  // const [password, setPassword] = useState('')

  // const enable = username && password

 

  useEffect(() => {
    let images= ref.current.querySelectorAll('img'),
    total = images.length,
    current = 0
    const imageSlider = () => {
     images[(current >0 ? current :total) - 1].classList.add('opacity-0')
     images[current].classList.remove('opacity-0')
     images = current === total -1 ? 0 : current +1;
    }
    imageSlider()
   let interval = setInterval(imageSlider,3000)
   return () => {
    clearInterval(interval)

   }
  }, [ref])

  const images =[
    'https://www.instagram.com/images/instagram/xig/homepage/screenshots/screenshot1-2x.png?__d=www' ,
    'https://www.instagram.com/images/instagram/xig/homepage/screenshots/screenshot2-2x.png?__d=www' ,
    'https://www.instagram.com/images/instagram/xig/homepage/screenshots/screenshot3-2x.png?__d=www' ,
    'https://www.instagram.com/images/instagram/xig/homepage/screenshots/screenshot4-2x.png?__d=www'
,
  ]

  if(user) {
    return <Navigate to={location.state?.return_url || '/'} replace={true} />
  }


  const handleSubmit = async (values, actions) => {
    // bu response olayını yapmamızın sebebi yanlış şifrede sayfayı gereksiz yere yenilemesin diye
  await login(values.username, values.password)
  }


  return (
    <div className="h-full w-full flex flex-wrap overflow-auto items-center gap-x-8 justify-center">

      <Helmet>
        <title>Login . Instagram</title>
      </Helmet>

      <div className=" hidden md:block w-[380px] h-[581px] bg-logo-pattern relative bg-[lenght:468.32px_634.15px] bg-[top_left_-46px] ">
        
        <div className="w-[250px] h-[538px] absolute top-[27px] right-[18px]" ref={ref}>
          {images.map((image, key)=>(
              <img key={key}
              className="w-full h-full absolute top-0 left-0 opacity-0 transition-opacity duration-700 ease-linear"
              src={image}
              alt="" />
       
          ))}
        </div>    
      </div>

      <div className="w-[350px] grid gap-y-3" >

      <div className=" bg-white border px-[40px] pt-10 pb-6">
        <div className="flex justify-center mb-8">
        <img className="h-[51px]" src="https://marka-logo.com/wp-content/uploads/2020/04/Instagram-Logo.png" alt=" "></img>
        </div>

        <Formik
        validationSchema={LoginSchema}
        initialValues={{
          username: '' ,
          password: ''
        }}
        onSubmit={handleSubmit}
        >
          {({ isSubmitting,isValid, dirty ,values }) => (
            <Form className="grid gap-y-1.5">
              <Input name="username" label="Phone number, username or email" />
          {/* <label className="block relative">
            <input type="text" value={username} onChange={e => setUsername(e.target.value)} required={true} className="bg-zinc-50 px-2 border rounded-sm outline-none text-xs focus:border-gray-400 w-full h-[38px] valid:pt-[10px] peer"/>
              <small className="absolute top-1/2 left-[9px] cursor-text pointer-events-none text-xs text-gray-400 -translate-y-1/2 transition-all peer-valid:text-[10px] peer-valid:top-2.5"> Phone number, username or email</small>
           
          </label> */}
          <Input type="password" name="password" label="Password" />
           {/* 
          <label className="block relative">
            <input type="password" required={true} value={password} onChange={e => setPassword(e.target.value)} className="bg-zinc-50 px-2 border rounded-sm outline-none text-xs focus:border-gray-400 w-full h-[38px] valid:pt-[10px] peer"/>
              <small className="absolute top-1/2 left-[9px] cursor-text pointer-events-none text-xs text-gray-400 -translate-y-1/2 transition-all peer-valid:text-[10px] peer-valid:top-2.5">Password</small>
          </label> */}
          <Button 
             type="submit" 
             disabled ={!isValid || !dirty || isSubmitting}
             >
            Log In
          </Button>

          <Separator />

          <a href="#" className="flex justify-center mb-2.5 items-center gap-x-2 text-sm font-semibold text-facebook">
            <AiFillFacebook size={20}/>
            Log in with Facebook
          </a>
          <a href="#" className="text-xs flex items-center justify-center text-link" >
            Forgot Password
          </a>

            </Form>

          )}
        </Formik>

      </div>
      <div className="bg-white border p-4 text-sm text-center "> 
        Don't have an account? <Link to="/auth/register" className="font-semibold text-brand">Sign up</Link>
      </div>
      
      </div>

    </div>
  
  );
}



