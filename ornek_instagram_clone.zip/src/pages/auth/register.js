import React from "react";
import { useRef, useEffect , useState} from "react";
import Input from "../../components/Input";
import {AiFillFacebook} from "react-icons/ai";
import { useNavigate, useLocation,Link } from "react-router-dom";
import { useDispatch } from "react-redux";
import { setUser } from "../../store/auth";
import Button from "../../components/Button";
import Separator from "../../components/Separator";
import { register } from "../../firebase";
import { Formik, Form } from "formik";
import { RegisterSchema } from "../../validation";
import { Helmet } from "react-helmet";
// birüstü firebase.js de yapabilirsin


export default function Register(){
   
  const navigate = useNavigate()
  const location = useLocation()


  const handleSubmit = async (values, actions) => {
    // bu response olayını yapmamızın sebebi yanlış şifrede sayfayı gereksiz yere yenilemesin diye
   const response = await register(values)
  if(response){

    navigate(location.state ?.return_url || '/', {
      replace: true
  
    })
  }  

  }
  return (

      <div className="w-[350px] grid gap-y-3" >

        <Helmet>
          <title>Regiser . Instagram</title>
        </Helmet>

      <div className=" bg-white border px-[40px] pt-10 pb-6">
        <div className="flex justify-center mb-4">
        <img className="h-[51px]" 
        src="https://marka-logo.com/wp-content/uploads/2020/04/Instagram-Logo.png" alt=" "></img>
        </div>
        <p className="text-[17px] font-semibold text-[#8e8e8e] text-center mb-6">
            Sign up to see photos and videos from your friends.
        </p>

        <Button>
        <a href="#" className="flex justify-center mb-2.5 items-center gap-x-2 text-sm font-semibold text-facebook">
            <AiFillFacebook size={20}/>
            Log in with Facebook
          </a>
        </Button>
        <Separator/>
        <Formik
        validationSchema={RegisterSchema}
        initialValues={{
          email: '',
          full_name: '',
          username: '' ,
          password: ''
        }}
        onSubmit={handleSubmit}
        >
          {({ isSubmitting,isValid, dirty ,values }) => (
            <Form className="grid gap-y-1.5">
          <Input name="email" label="Email" />
          <Input name="full_name" label="Full Name" />
          <Input name="username" label="Username" />
          <Input type="password" name="password" label="Password" />
        
          <p className="text-xs text-[#8e8e8e] py-2 ">
        Hizmetimizi kullanan kişiler senin iletişim bilgilerini Instagram'a yüklemiş olabilir. <a href="#" className="font-semibold">Daha Fazla Bilgi Al</a>
        <br/> <br/>
        Kaydolarak, <a href="#" className="font-semibold">Koşullarımızı, Gizlilik İlkemizi</a> ve <a href="#" className="font-semibold">Çerezler İlkemizi</a> kabul etmiş olursun.
          </p>
           {/* 
          <label className="block relative">
            <input type="password" required={true} value={password} onChange={e => setPassword(e.target.value)} className="bg-zinc-50 px-2 border rounded-sm outline-none text-xs focus:border-gray-400 w-full h-[38px] valid:pt-[10px] peer"/>
              <small className="absolute top-1/2 left-[9px] cursor-text pointer-events-none text-xs text-gray-400 -translate-y-1/2 transition-all peer-valid:text-[10px] peer-valid:top-2.5">Password</small>
          </label> */}
          <Button 
             type="submit" 
             disabled ={!isValid || !dirty || isSubmitting}
             >
            Sign up
          </Button>
            </Form>
          )}
        </Formik>

      </div>
      <div className="bg-white border p-4 text-sm text-center "> 
        Have an account? <Link to="/auth/login" className="font-semibold text-brand">Log in</Link>
      </div>
      
      </div>

   
  
  );
}



