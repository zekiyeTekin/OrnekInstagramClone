import { Helmet } from "react-helmet"

export default function Home(){
    return (
        <div>
            <Helmet>
                <title>Instagram</title>
            </Helmet>
            home page
        </div>
    )
}